// src/AppContext.tsx — typed state, callbacks, session management
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { AppState, WorkoutSession, WorkoutLog } from './types';
import { loadState, saveState, DEFAULTS } from './storage';
import { getTheme } from './theme';
import { Theme } from './types';
import { calcStreak, checkAchievements, fmt, weekDates } from './helpers';
import { PLAN } from './data';

interface AppContextValue {
  state: AppState;
  setState: (patch: Partial<AppState> | ((s: AppState) => AppState)) => void;
  T: Theme;
  session: WorkoutSession | null;
  setSession: React.Dispatch<React.SetStateAction<WorkoutSession | null>>;
  startWorkout: (dayIdx: number) => void;
  finishWorkout: () => void;
  editHistory: (date: string, log: WorkoutLog) => void;
  update1RM: (val: number) => void;
  loading: boolean;
}

const AppContext = createContext<AppContextValue>({} as AppContextValue);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setStateRaw] = useState<AppState>(DEFAULTS);
  const [session, setSession] = useState<WorkoutSession | null>(null);
  const [loading, setLoading] = useState(true);

  // Load persisted state
  useEffect(() => {
    loadState().then(s => {
      setStateRaw(s);
      setLoading(false);
    });
  }, []);

  // Typed setState with persistence
  const setState = useCallback(
    (patch: Partial<AppState> | ((s: AppState) => AppState)) => {
      setStateRaw(prev => {
        const next = typeof patch === 'function' ? patch(prev) : { ...prev, ...patch };
        saveState(next); // debounced 300ms
        return next;
      });
    },
    []
  );

  const T = getTheme(state.themeId || 'cosmos');

  // Start a workout session
  const startWorkout = useCallback((dayIdx: number) => {
    const plan = PLAN[dayIdx];
    const exerciseLogs: Record<string, { done: boolean; value: string }[]> = {};
    plan.exercises.forEach(ex => {
      exerciseLogs[ex.id] = Array.from({ length: ex.sets }, () => ({ done: false, value: '' }));
    });
    setSession({
      dayIdx,
      phase: plan.warmup.length > 0 ? 'warmup' : 'exercises',
      warmupDone: new Set(),
      exerciseLogs,
      showRest: false,
      difficulty: 5,
      painNotes: '',
      workoutNotes: '',
      startTime: new Date().toISOString(),
    });
  }, []);

  // Finish and save workout
  const finishWorkout = useCallback(() => {
    if (!session) return;
    const dates = weekDates();
    const date = fmt(dates[session.dayIdx]);
    setState(s => {
      const newHist: Record<string, WorkoutLog> = {
        ...s.history,
        [date]: {
          dayId: session.dayIdx + 1,
          completed: true,
          exercises: session.exerciseLogs,
          difficulty: session.difficulty,
          painNotes: session.painNotes,
          workoutNotes: session.workoutNotes,
          startTime: session.startTime,
          endTime: new Date().toISOString(),
        },
      };
      const newAch = checkAchievements({ ...s, history: newHist });
      return {
        ...s,
        history: newHist,
        streak: calcStreak(newHist),
        achievements: newAch,
      };
    });
    setSession(null);
  }, [session, setState]);

  // Edit a past workout
  const editHistory = useCallback((date: string, log: WorkoutLog) => {
    setState(s => ({ ...s, history: { ...s.history, [date]: log } }));
  }, [setState]);

  // Update max pushups
  const update1RM = useCallback((val: number) => {
    setState(s => ({ ...s, user: { ...s.user, maxPushups: val } }));
  }, [setState]);

  return (
    <AppContext.Provider value={{
      state, setState, T, session, setSession,
      startWorkout, finishWorkout, editHistory, update1RM, loading,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  return useContext(AppContext);
}
