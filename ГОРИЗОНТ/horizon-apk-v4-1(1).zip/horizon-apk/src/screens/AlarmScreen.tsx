// src/screens/AlarmScreen.tsx — @notifee/react-native, defaultValue inputs, ▲▼ time picker
import React, { useState, useRef, useMemo } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, TextInput,
  Modal, Switch, Alert, Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Plus, X, Bell } from 'lucide-react-native';
// NOTE: @notifee/react-native must be installed: npx expo install @notifee/react-native
// Graceful fallback if not installed yet
let notifee: any = null;
let TriggerType: any = null;
let RepeatFrequency: any = null;
let AndroidImportance: any = null;
try {
  const n = require('@notifee/react-native');
  notifee = n.default;
  TriggerType = n.TriggerType;
  RepeatFrequency = n.RepeatFrequency;
  AndroidImportance = n.AndroidImportance;
} catch {
  // expo-notifications fallback or just no notifications
}

import { useApp } from '../AppContext';
import { Card, Lbl, ProgressBar } from '../components';
import { uid, TODAY, fmtSleep } from '../helpers';
import { SOUND_OPTIONS } from '../data';
import { Alarm, AlarmCategory, AlarmSoundId } from '../types';

const DAYS_LABEL = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];

const CATEGORY_INFO: Record<AlarmCategory, { emoji: string; color: string; label: string }> = {
  wake:    { emoji: '🌅', label: 'Подъём',     color: '#FFD600' },
  workout: { emoji: '💪', label: 'Тренировка', color: '#00C4F0' },
  meal:    { emoji: '🍽️', label: 'Приём пищи', color: '#00E676' },
  meds:    { emoji: '💊', label: 'Лекарство',  color: '#FF4455' },
  custom:  { emoji: '🔔', label: 'Другое',     color: '#C77DFF' },
};

// Create or ensure notification channel exists (Android)
async function ensureChannel(): Promise<void> {
  if (!notifee || !AndroidImportance) return;
  await notifee.createChannel({
    id: 'horizon-alarms',
    name: 'Будильники Горизонт',
    importance: AndroidImportance.HIGH,
    sound: 'default',
    vibrationPattern: [300, 500, 300, 500],
    bypassDnd: true,
  });
}

async function requestPermissions(): Promise<boolean> {
  if (!notifee) return false;
  const settings = await notifee.requestPermission();
  return settings.authorizationStatus >= 1;
}

async function scheduleAlarm(alarm: Alarm): Promise<string | null> {
  if (!notifee || !TriggerType) return null;
  try {
    const granted = await requestPermissions();
    if (!granted) return null;
    await ensureChannel();

    // Cancel previous
    if (alarm.notifId) {
      await notifee.cancelTriggerNotification(alarm.notifId).catch(() => {});
    }

    const cat = CATEGORY_INFO[alarm.category];
    const body = { title: `${cat.emoji} ${alarm.label || cat.label}`, body: `${String(alarm.hour).padStart(2,'0')}:${String(alarm.minute).padStart(2,'0')}` };
    const android = { channelId: 'horizon-alarms', pressAction: { id: 'default' } };
    const ios = { sound: alarm.soundId || 'default' };

    if (alarm.days.length === 0) {
      // One-time alarm
      const now = new Date();
      const trigger = new Date();
      trigger.setHours(alarm.hour, alarm.minute, 0, 0);
      if (trigger <= now) trigger.setDate(trigger.getDate() + 1);

      const id = await notifee.createTriggerNotification(
        { ...body, android, ios, data: { alarmId: alarm.id } },
        { type: TriggerType.TIMESTAMP, timestamp: trigger.getTime(), alarmManager: { allowWhileIdle: true } }
      );
      return id;
    } else {
      // Weekly repeating — one notification per active day
      const ids: string[] = [];
      for (const day of alarm.days) {
        const now = new Date();
        const trigger = new Date();
        // Find next occurrence of this weekday
        const currentDay = trigger.getDay();
        let daysUntil = (day - currentDay + 7) % 7;
        if (daysUntil === 0 && (alarm.hour * 60 + alarm.minute) <= (now.getHours() * 60 + now.getMinutes())) {
          daysUntil = 7;
        }
        trigger.setDate(trigger.getDate() + daysUntil);
        trigger.setHours(alarm.hour, alarm.minute, 0, 0);

        const id = await notifee.createTriggerNotification(
          { ...body, android, ios, data: { alarmId: alarm.id } },
          {
            type: TriggerType.TIMESTAMP,
            timestamp: trigger.getTime(),
            repeatFrequency: RepeatFrequency.WEEKLY,
            alarmManager: { allowWhileIdle: true },
          }
        );
        ids.push(id);
      }
      return ids[0] || null;
    }
  } catch {
    return null;
  }
}

async function cancelAlarmNotif(alarm: Alarm): Promise<void> {
  if (!notifee || !alarm.notifId) return;
  await notifee.cancelTriggerNotification(alarm.notifId).catch(() => {});
}

// ── Time picker modal (defaultValue for inputs as required)
function AlarmAddModal({ T, onSave, onClose, initial }: {
  T: any;
  onSave: (data: Omit<Alarm, 'id' | 'enabled' | 'notifId'>) => void;
  onClose: () => void;
  initial?: Alarm | null;
}) {
  const [hour, setHour] = useState(initial?.hour ?? 7);
  const [minute, setMinute] = useState(initial?.minute ?? 0);
  const [label, setLabel] = useState(initial?.label ?? '');
  const [days, setDays] = useState<number[]>(initial?.days ?? [1, 2, 3, 4, 5]);
  const [vibrate, setVibrate] = useState(initial?.vibrate ?? true);
  const [smartWake, setSmartWake] = useState(initial?.smartWake ?? false);
  const [category, setCategory] = useState<AlarmCategory>(initial?.category ?? 'wake');
  const [soundId, setSoundId] = useState<AlarmSoundId>(initial?.soundId ?? 'default');

  const hourRef = useRef<TextInput>(null);
  const minRef = useRef<TextInput>(null);

  const toggleDay = (d: number) =>
    setDays(prev => prev.includes(d) ? prev.filter(x => x !== d) : [...prev, d].sort((a, b) => a - b));

  const fmtTime = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;

  const setPreset = (h: number, m: number) => { setHour(h); setMinute(m); };

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.88)', justifyContent: 'flex-end' }}>
        <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
          onTouchEnd={onClose} />

        <View style={{ backgroundColor: T.surf, borderTopLeftRadius: 22, borderTopRightRadius: 22, maxHeight: '94%' }}>
          <View style={{ padding: 16, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderBottomWidth: 1, borderBottomColor: T.bord }}>
            <Text style={{ fontFamily: 'BarlowCondensed_900Black', fontSize: 20, color: T.txt }}>
              {initial ? 'Изменить' : 'Новый'} будильник
            </Text>
            <TouchableOpacity onPress={onClose} style={{ width: 30, height: 30, borderRadius: 15, backgroundColor: T.lo, borderWidth: 1, borderColor: T.bord, alignItems: 'center', justifyContent: 'center' }}>
              <X size={14} color={T.muted} />
            </TouchableOpacity>
          </View>

          <ScrollView contentContainerStyle={{ padding: 16 }} keyboardShouldPersistTaps="handled">
            {/* ── Time Picker with ▲▼ buttons ── */}
            <View style={{ alignItems: 'center', marginBottom: 16 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                {/* Hours */}
                <View style={{ alignItems: 'center', gap: 6 }}>
                  <TouchableOpacity
                    onPress={() => setHour(h => (h + 1) % 24)}
                    style={{ width: 44, height: 34, borderRadius: 8, backgroundColor: T.lo, borderWidth: 1, borderColor: T.bord, alignItems: 'center', justifyContent: 'center' }}>
                    <Text style={{ color: T.primary, fontSize: 18, lineHeight: 20 }}>▲</Text>
                  </TouchableOpacity>
                  {/* defaultValue — NOT value — so keyboard works */}
                  <TextInput
                    ref={hourRef}
                    defaultValue={String(hour).padStart(2, '0')}
                    keyboardType="number-pad"
                    maxLength={2}
                    selectTextOnFocus
                    onEndEditing={e => {
                      const v = parseInt(e.nativeEvent.text, 10);
                      setHour(isNaN(v) ? 7 : Math.min(23, Math.max(0, v)));
                    }}
                    style={{
                      width: 86, height: 76, borderRadius: 12,
                      backgroundColor: T.lo, borderWidth: 2, borderColor: T.primary,
                      color: T.txt, fontFamily: 'BarlowCondensed_900Black', fontSize: 44,
                      textAlign: 'center',
                    }}
                  />
                  <TouchableOpacity
                    onPress={() => setHour(h => (h - 1 + 24) % 24)}
                    style={{ width: 44, height: 34, borderRadius: 8, backgroundColor: T.lo, borderWidth: 1, borderColor: T.bord, alignItems: 'center', justifyContent: 'center' }}>
                    <Text style={{ color: T.primary, fontSize: 18, lineHeight: 20 }}>▼</Text>
                  </TouchableOpacity>
                  <Text style={{ fontFamily: 'BarlowCondensed_700Bold', fontSize: 11, color: T.muted, letterSpacing: 1 }}>ЧАСЫ</Text>
                </View>

                <Text style={{ fontFamily: 'BarlowCondensed_900Black', fontSize: 44, color: T.txt, marginBottom: 20 }}>:</Text>

                {/* Minutes ±5 */}
                <View style={{ alignItems: 'center', gap: 6 }}>
                  <TouchableOpacity
                    onPress={() => setMinute(m => (m + 5) % 60)}
                    style={{ width: 44, height: 34, borderRadius: 8, backgroundColor: T.lo, borderWidth: 1, borderColor: T.bord, alignItems: 'center', justifyContent: 'center' }}>
                    <Text style={{ color: T.primary, fontSize: 18, lineHeight: 20 }}>▲</Text>
                  </TouchableOpacity>
                  <TextInput
                    ref={minRef}
                    defaultValue={String(minute).padStart(2, '0')}
                    keyboardType="number-pad"
                    maxLength={2}
                    selectTextOnFocus
                    onEndEditing={e => {
                      const v = parseInt(e.nativeEvent.text, 10);
                      setMinute(isNaN(v) ? 0 : Math.min(59, Math.max(0, v)));
                    }}
                    style={{
                      width: 86, height: 76, borderRadius: 12,
                      backgroundColor: T.lo, borderWidth: 2, borderColor: T.bord,
                      color: T.txt, fontFamily: 'BarlowCondensed_900Black', fontSize: 44,
                      textAlign: 'center',
                    }}
                  />
                  <TouchableOpacity
                    onPress={() => setMinute(m => (m - 5 + 60) % 60)}
                    style={{ width: 44, height: 34, borderRadius: 8, backgroundColor: T.lo, borderWidth: 1, borderColor: T.bord, alignItems: 'center', justifyContent: 'center' }}>
                    <Text style={{ color: T.primary, fontSize: 18, lineHeight: 20 }}>▼</Text>
                  </TouchableOpacity>
                  <Text style={{ fontFamily: 'BarlowCondensed_700Bold', fontSize: 11, color: T.muted, letterSpacing: 1 }}>МИН</Text>
                </View>
              </View>

              {/* Quick presets */}
              <View style={{ flexDirection: 'row', gap: 6, marginTop: 12 }}>
                {[[6,0],[6,30],[7,0],[7,30],[8,0]].map(([h, m]) => (
                  <TouchableOpacity key={`${h}${m}`} onPress={() => setPreset(h, m)}
                    style={{ paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8, borderWidth: 1.5,
                      borderColor: hour === h && minute === m ? T.primary : T.bord,
                      backgroundColor: hour === h && minute === m ? T.primary + '22' : T.lo }}>
                    <Text style={{ fontFamily: 'BarlowCondensed_700Bold', fontSize: 13,
                      color: hour === h && minute === m ? T.primary : T.muted }}>
                      {`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Category */}
            <Lbl T={T} style={{ marginBottom: 8 }}>Категория</Lbl>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 14 }}>
              {(Object.entries(CATEGORY_INFO) as [AlarmCategory, typeof CATEGORY_INFO[AlarmCategory]][]).map(([k, v]) => (
                <TouchableOpacity key={k} onPress={() => setCategory(k)}
                  style={{ paddingHorizontal: 10, paddingVertical: 6, borderRadius: 10, borderWidth: 1.5,
                    borderColor: category === k ? v.color : T.bord,
                    backgroundColor: category === k ? v.color + '22' : T.lo,
                    flexDirection: 'row', alignItems: 'center', gap: 5 }}>
                  <Text style={{ fontSize: 14 }}>{v.emoji}</Text>
                  <Text style={{ fontFamily: 'BarlowCondensed_700Bold', fontSize: 12, color: category === k ? v.color : T.muted }}>{v.label}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Label */}
            <Lbl T={T} style={{ marginBottom: 6 }}>Название</Lbl>
            <TextInput value={label} onChangeText={setLabel}
              placeholder={CATEGORY_INFO[category].label} placeholderTextColor={T.muted}
              style={{ height: 40, borderRadius: 9, borderWidth: 1.5, borderColor: T.bord,
                backgroundColor: T.lo, color: T.txt, fontFamily: 'Barlow_400Regular',
                fontSize: 15, paddingHorizontal: 12, marginBottom: 14 }} />

            {/* Days */}
            <Lbl T={T} style={{ marginBottom: 8 }}>Дни повторения</Lbl>
            <View style={{ flexDirection: 'row', gap: 5, marginBottom: 8 }}>
              {DAYS_LABEL.map((d, i) => (
                <TouchableOpacity key={i} onPress={() => toggleDay(i)}
                  style={{ flex: 1, height: 36, borderRadius: 8, borderWidth: 1.5,
                    borderColor: days.includes(i) ? T.primary : T.bord,
                    backgroundColor: days.includes(i) ? T.primary + '22' : T.lo,
                    alignItems: 'center', justifyContent: 'center' }}>
                  <Text style={{ fontFamily: 'BarlowCondensed_700Bold', fontSize: 11, color: days.includes(i) ? T.primary : T.muted }}>{d}</Text>
                </TouchableOpacity>
              ))}
            </View>
            {/* Shortcut presets */}
            <View style={{ flexDirection: 'row', gap: 6, marginBottom: 14, flexWrap: 'wrap' }}>
              {[
                { l: 'Будни',       d: [1,2,3,4,5] },
                { l: 'Выходные',    d: [0,6] },
                { l: 'Каждый день', d: [0,1,2,3,4,5,6] },
                { l: 'Однажды',     d: [] },
              ].map(p => {
                const active = JSON.stringify(days.slice().sort()) === JSON.stringify(p.d.slice().sort());
                return (
                  <TouchableOpacity key={p.l} onPress={() => setDays(p.d)}
                    style={{ paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8, borderWidth: 1,
                      borderColor: active ? T.success : T.bord,
                      backgroundColor: active ? T.success + '18' : T.lo }}>
                    <Text style={{ fontFamily: 'BarlowCondensed_700Bold', fontSize: 11, color: active ? T.success : T.muted }}>{p.l}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            {/* Sound */}
            <Lbl T={T} style={{ marginBottom: 8 }}>Звук</Lbl>
            <View style={{ flexDirection: 'row', gap: 8, marginBottom: 14 }}>
              {SOUND_OPTIONS.map(s => (
                <TouchableOpacity key={s.id} onPress={() => setSoundId(s.id)}
                  style={{ flex: 1, paddingVertical: 8, borderRadius: 9, borderWidth: 1.5,
                    borderColor: soundId === s.id ? T.primary : T.bord,
                    backgroundColor: soundId === s.id ? T.primary + '18' : T.lo,
                    alignItems: 'center', gap: 2 }}>
                  <Text style={{ fontSize: 18 }}>{s.emoji}</Text>
                  <Text style={{ fontFamily: 'BarlowCondensed_700Bold', fontSize: 10, color: soundId === s.id ? T.primary : T.muted }}>{s.label}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Toggles */}
            {[
              { label: '📳 Вибрация', value: vibrate, onToggle: () => setVibrate(v => !v) },
              { label: '🌙 Умный подъём (±30 мин)', value: smartWake, onToggle: () => setSmartWake(v => !v) },
            ].map(opt => (
              <View key={opt.label} style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
                paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: T.bord }}>
                <Text style={{ fontFamily: 'Barlow_400Regular', fontSize: 14, color: T.txt }}>{opt.label}</Text>
                <Switch value={opt.value} onValueChange={opt.onToggle}
                  trackColor={{ false: T.bord, true: T.primary + '99' }}
                  thumbColor={opt.value ? T.primary : T.muted} />
              </View>
            ))}

            {/* Actions */}
            <View style={{ flexDirection: 'row', gap: 8, marginTop: 16 }}>
              <TouchableOpacity onPress={onClose}
                style={{ flex: 1, height: 44, borderRadius: 10, borderWidth: 1, borderColor: T.bord,
                  backgroundColor: T.lo, alignItems: 'center', justifyContent: 'center' }}>
                <Text style={{ fontFamily: 'BarlowCondensed_700Bold', fontSize: 14, color: T.muted }}>Отмена</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => onSave({ hour, minute, label: label || CATEGORY_INFO[category].label, days, vibrate, smartWake, category, soundId })}
                style={{ flex: 2, height: 44, borderRadius: 10, backgroundColor: T.primary, alignItems: 'center', justifyContent: 'center' }}>
                <Text style={{ fontFamily: 'BarlowCondensed_900Black', fontSize: 15, color: '#000' }}>
                  Сохранить {fmtTime}
                </Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

// ── Main screen
export default function AlarmScreen() {
  const { state, setState, T } = useApp();
  const alarms: Alarm[] = (state as any).alarms || [];
  const [showAdd, setShowAdd] = useState(false);
  const [editAlarm, setEditAlarm] = useState<Alarm | null>(null);
  const [sub, setSub] = useState<'alarms' | 'analysis'>('alarms');

  const setAlarms = (fn: (a: Alarm[]) => Alarm[]) => {
    setState((s: any) => ({ ...s, alarms: fn(s.alarms || []) }));
  };

  const addOrUpdateAlarm = async (data: Omit<Alarm, 'id' | 'enabled' | 'notifId'>) => {
    if (editAlarm) {
      const updated: Alarm = { ...editAlarm, ...data };
      const notifId = await scheduleAlarm(updated);
      if (notifId) updated.notifId = notifId;
      setAlarms(prev => prev.map(a => a.id === editAlarm.id ? updated : a));
    } else {
      const alarm: Alarm = { id: uid(), enabled: true, ...data };
      const notifId = await scheduleAlarm(alarm);
      if (notifId) alarm.notifId = notifId;
      setAlarms(prev => [...prev, alarm].sort((a, b) => a.hour * 60 + a.minute - (b.hour * 60 + b.minute)));
    }
    setShowAdd(false);
    setEditAlarm(null);
  };

  const toggleAlarm = async (id: string) => {
    const alarm = alarms.find(a => a.id === id);
    if (!alarm) return;
    const next: Alarm = { ...alarm, enabled: !alarm.enabled };
    if (next.enabled) {
      const notifId = await scheduleAlarm(next);
      if (notifId) next.notifId = notifId;
    } else {
      await cancelAlarmNotif(alarm);
      next.notifId = undefined;
    }
    setAlarms(prev => prev.map(a => a.id === id ? next : a));
  };

  const deleteAlarm = (id: string) => {
    const alarm = alarms.find(a => a.id === id);
    if (alarm) cancelAlarmNotif(alarm);
    setAlarms(prev => prev.filter(a => a.id !== id));
  };

  const fmtAlarmTime = (a: Alarm) =>
    `${String(a.hour).padStart(2, '0')}:${String(a.minute).padStart(2, '0')}`;

  const daysLabel = (days: number[]) => {
    if (!days.length) return 'Однажды';
    if (days.length === 7) return 'Каждый день';
    if (JSON.stringify([...days].sort()) === JSON.stringify([1,2,3,4,5])) return 'Будни';
    if (JSON.stringify([...days].sort()) === JSON.stringify([0,6])) return 'Выходные';
    return days.map(d => DAYS_LABEL[d]).join(' ');
  };

  // Next occurrence
  const getNextLabel = (alarm: Alarm): string | null => {
    const now = new Date();
    const todayDay = now.getDay();
    if (!alarm.enabled) return null;
    if (alarm.days.length === 0) return 'Однажды';
    for (let i = 0; i < 7; i++) {
      const checkDay = (todayDay + i) % 7;
      if (!alarm.days.includes(checkDay)) continue;
      if (i === 0 && alarm.hour * 60 + alarm.minute <= now.getHours() * 60 + now.getMinutes()) continue;
      if (i === 0) return 'СЕГОДНЯ';
      if (i === 1) return 'ЗАВТРА';
      return DAYS_LABEL[checkDay];
    }
    return null;
  };

  // Sleep analysis
  const sleepEntries = (state.journal || []).filter(j => (j.sleep || 0) > 0).slice(-14);
  const sleepScore = useMemo(() => {
    if (sleepEntries.length < 3) return null;
    const avg = sleepEntries.reduce((s, j) => s + (j.sleep || 0), 0) / sleepEntries.length;
    return { avg: avg.toFixed(1), score: Math.min(100, Math.round((avg / 8) * 100)), count: sleepEntries.length };
  }, [sleepEntries]);

  const uid_local = () => Math.random().toString(36).slice(2, 9);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: T.bg }}>
      {/* Header */}
      <View style={{ backgroundColor: T.surf, borderBottomWidth: 1, borderBottomColor: T.bord,
        paddingHorizontal: 16, paddingVertical: 12, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <View>
          <Text style={{ fontFamily: 'BarlowCondensed_900Black', fontSize: 22, color: T.txt, letterSpacing: 1 }}>⏰ Будильники</Text>
          <Text style={{ fontFamily: 'Barlow_400Regular', fontSize: 11, color: T.muted }}>
            {alarms.filter(a => a.enabled).length} активных
            {!notifee && ' · notifee не установлен'}
          </Text>
        </View>
        <TouchableOpacity onPress={() => setShowAdd(true)}
          style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: T.primary, alignItems: 'center', justifyContent: 'center' }}>
          <Plus size={20} color="#000" />
        </TouchableOpacity>
      </View>

      {/* Sub-tabs */}
      <View style={{ flexDirection: 'row', backgroundColor: T.surf, borderBottomWidth: 1, borderBottomColor: T.bord }}>
        {[{ id: 'alarms' as const, l: '🔔 Будильники' }, { id: 'analysis' as const, l: '📊 Сон' }].map(t => (
          <TouchableOpacity key={t.id} onPress={() => setSub(t.id)}
            style={{ flex: 1, paddingVertical: 11, alignItems: 'center', borderBottomWidth: 2,
              borderBottomColor: sub === t.id ? T.primary : 'transparent' }}>
            <Text style={{ fontFamily: 'BarlowCondensed_700Bold', fontSize: 13, color: sub === t.id ? T.primary : T.muted }}>{t.l}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView contentContainerStyle={{ padding: 14, paddingBottom: 24 }}>

        {/* ── ALARMS ── */}
        {sub === 'alarms' && (<>
          {alarms.length === 0 ? (
            <View style={{ alignItems: 'center', paddingVertical: 60 }}>
              <Text style={{ fontSize: 56, marginBottom: 12 }}>⏰</Text>
              <Text style={{ fontFamily: 'BarlowCondensed_900Black', fontSize: 22, color: T.txt, marginBottom: 8 }}>Нет будильников</Text>
              <Text style={{ fontFamily: 'Barlow_400Regular', fontSize: 14, color: T.muted, textAlign: 'center', lineHeight: 21 }}>
                Подъём, тренировка, лекарство{'\n'}или приём пищи
              </Text>
              <TouchableOpacity onPress={() => setShowAdd(true)}
                style={{ marginTop: 20, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 14, backgroundColor: T.primary }}>
                <Text style={{ fontFamily: 'BarlowCondensed_900Black', fontSize: 16, color: '#000' }}>+ Добавить будильник</Text>
              </TouchableOpacity>
            </View>
          ) : (<>
            {alarms.map(alarm => {
              const cat = CATEGORY_INFO[alarm.category];
              const nextLabel = getNextLabel(alarm);
              return (
                <Card key={alarm.id} T={T} style={{ marginBottom: 10, opacity: alarm.enabled ? 1 : 0.55,
                  borderLeftWidth: 4, borderLeftColor: alarm.enabled ? cat.color : T.bord }}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                    <TouchableOpacity onPress={() => { setEditAlarm(alarm); setShowAdd(true); }} style={{ flex: 1 }}>
                      <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 8, marginBottom: 4 }}>
                        <Text style={{ fontSize: 18 }}>{cat.emoji}</Text>
                        <Text style={{ fontFamily: 'BarlowCondensed_900Black', fontSize: 36, color: alarm.enabled ? T.txt : T.muted, lineHeight: 40 }}>
                          {fmtAlarmTime(alarm)}
                        </Text>
                        {nextLabel && (
                          <View style={{ paddingHorizontal: 7, paddingVertical: 2, backgroundColor: nextLabel === 'СЕГОДНЯ' ? T.success + '22' : T.warn + '22',
                            borderRadius: 6, marginBottom: 5 }}>
                            <Text style={{ fontFamily: 'BarlowCondensed_700Bold', fontSize: 10,
                              color: nextLabel === 'СЕГОДНЯ' ? T.success : T.warn }}>{nextLabel}</Text>
                          </View>
                        )}
                      </View>
                      <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
                        <Text style={{ fontFamily: 'Barlow_400Regular', fontSize: 13, color: T.muted }}>{alarm.label}</Text>
                        <Text style={{ fontFamily: 'Barlow_400Regular', fontSize: 11, color: T.muted }}>· {daysLabel(alarm.days)}</Text>
                        {alarm.vibrate && <Text style={{ fontSize: 10 }}>📳</Text>}
                        {alarm.smartWake && <Text style={{ fontSize: 10 }}>🌙</Text>}
                        {alarm.soundId !== 'default' && <Text style={{ fontSize: 10 }}>{SOUND_OPTIONS.find(s => s.id === alarm.soundId)?.emoji}</Text>}
                      </View>
                    </TouchableOpacity>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                      <Switch value={alarm.enabled} onValueChange={() => toggleAlarm(alarm.id)}
                        trackColor={{ false: T.bord, true: cat.color + '99' }}
                        thumbColor={alarm.enabled ? cat.color : T.muted} />
                      <TouchableOpacity
                        onPress={() => Alert.alert('Удалить будильник?', fmtAlarmTime(alarm), [
                          { text: 'Отмена', style: 'cancel' },
                          { text: 'Удалить', style: 'destructive', onPress: () => deleteAlarm(alarm.id) },
                        ])} style={{ padding: 6 }}>
                        <X size={14} color={T.muted} />
                      </TouchableOpacity>
                    </View>
                  </View>
                </Card>
              );
            })}
            <TouchableOpacity onPress={() => setShowAdd(true)}
              style={{ height: 46, borderRadius: 12, borderWidth: 2, borderColor: T.bord,
                alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 8, marginTop: 4 }}>
              <Plus size={16} color={T.muted} />
              <Text style={{ fontFamily: 'BarlowCondensed_700Bold', fontSize: 14, color: T.muted }}>Добавить будильник</Text>
            </TouchableOpacity>
          </>)}
        </>)}

        {/* ── SLEEP ANALYSIS ── */}
        {sub === 'analysis' && (<>
          <Text style={{ fontFamily: 'BarlowCondensed_900Black', fontSize: 22, color: T.txt, marginBottom: 4 }}>Анализ сна</Text>
          <Text style={{ fontFamily: 'Barlow_400Regular', fontSize: 13, color: T.muted, marginBottom: 14 }}>
            Данные берутся из вкладки Дневник
          </Text>

          {!sleepScore ? (
            <Card T={T} style={{ alignItems: 'center', padding: 28 }}>
              <Text style={{ fontSize: 44, marginBottom: 14 }}>💤</Text>
              <Text style={{ fontFamily: 'BarlowCondensed_700Bold', fontSize: 18, color: T.txt, marginBottom: 6 }}>Нужно минимум 3 записи сна</Text>
              <Text style={{ fontFamily: 'Barlow_400Regular', fontSize: 13, color: T.muted, textAlign: 'center' }}>
                Записывай сон в Дневнике → вкладка «📓 Дневник»
              </Text>
            </Card>
          ) : (<>
            {/* Score */}
            <Card T={T} style={{ marginBottom: 12,
              backgroundColor: sleepScore.score >= 80 ? T.success + '10' : sleepScore.score >= 60 ? T.warn + '10' : T.danger + '10',
              borderWidth: 1, borderColor: sleepScore.score >= 80 ? T.success + '44' : sleepScore.score >= 60 ? T.warn + '44' : T.danger + '44' }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                <View>
                  <Text style={{ fontFamily: 'BarlowCondensed_900Black', fontSize: 52, lineHeight: 56,
                    color: sleepScore.score >= 80 ? T.success : sleepScore.score >= 60 ? T.warn : T.danger }}>
                    {sleepScore.score}
                  </Text>
                  <Text style={{ fontFamily: 'Barlow_400Regular', fontSize: 13, color: T.muted }}>Sleep Score / 100</Text>
                </View>
                <View style={{ alignItems: 'flex-end' }}>
                  <Text style={{ fontFamily: 'BarlowCondensed_900Black', fontSize: 32, color: T.txt }}>
                    {fmtSleep(parseFloat(sleepScore.avg))}
                  </Text>
                  <Text style={{ fontFamily: 'Barlow_400Regular', fontSize: 12, color: T.muted }}>
                    среднее за {sleepScore.count} ночей
                  </Text>
                  <Text style={{ fontFamily: 'BarlowCondensed_700Bold', fontSize: 14, marginTop: 4,
                    color: sleepScore.score >= 80 ? T.success : sleepScore.score >= 60 ? T.warn : T.danger }}>
                    {sleepScore.score >= 80 ? '😴 Отлично' : sleepScore.score >= 60 ? '😐 Нормально' : '😰 Мало сна'}
                  </Text>
                </View>
              </View>
              <ProgressBar pct={sleepScore.score}
                color={sleepScore.score >= 80 ? T.success : sleepScore.score >= 60 ? T.warn : T.danger}
                T={T} height={8} />
            </Card>

            {/* Last 7 nights */}
            <Card T={T} style={{ marginBottom: 12 }}>
              <Lbl T={T} style={{ marginBottom: 12 }}>Последние ночи</Lbl>
              {sleepEntries.slice(0, 7).reverse().map((entry, i) => {
                const h = entry.sleep || 0;
                const col = h >= 7 ? T.success : h >= 6 ? T.warn : T.danger;
                return (
                  <View key={entry.id || i} style={{ marginBottom: 8 }}>
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 }}>
                      <Text style={{ fontFamily: 'Barlow_400Regular', fontSize: 13, color: T.txt }}>
                        {new Date(entry.date + 'T12:00:00').toLocaleDateString('ru-RU', { weekday: 'short', day: 'numeric', month: 'short' })}
                      </Text>
                      <Text style={{ fontFamily: 'BarlowCondensed_700Bold', fontSize: 14, color: col }}>
                        {fmtSleep(h)}
                      </Text>
                    </View>
                    <ProgressBar pct={Math.min((h / 9) * 100, 100)} color={col} T={T} height={5} />
                  </View>
                );
              })}
            </Card>

            {/* Recommendations */}
            <Card T={T}>
              <Lbl T={T} style={{ marginBottom: 10 }}>💡 Рекомендации</Lbl>
              {[
                parseFloat(sleepScore.avg) < 7 && { icon: '😴', text: 'Старайся спать минимум 7 часов. Хронический недосып накапливается.' },
                parseFloat(sleepScore.avg) > 9 && { icon: '⏰', text: 'Слишком долгий сон может говорить об усталости. Оптимум: 7-9 часов.' },
                { icon: '🔄', text: 'Ложись и вставай в одно время каждый день — даже в выходные.' },
                { icon: '📵', text: 'Убери экраны за 30 мин до сна — синий свет мешает выработке мелатонина.' },
              ].filter(Boolean).slice(0, 3).map((rec: any, i, arr) => (
                <View key={i} style={{ flexDirection: 'row', gap: 10, paddingVertical: 8,
                  borderBottomWidth: i < arr.length - 1 ? 1 : 0, borderBottomColor: T.bord }}>
                  <Text style={{ fontSize: 18 }}>{rec.icon}</Text>
                  <Text style={{ fontFamily: 'Barlow_400Regular', fontSize: 13, color: T.txt, lineHeight: 19, flex: 1 }}>{rec.text}</Text>
                </View>
              ))}
            </Card>
          </>)}
        </>)}
      </ScrollView>

      {/* Modal */}
      {showAdd && (
        <AlarmAddModal
          T={T}
          initial={editAlarm}
          onSave={addOrUpdateAlarm}
          onClose={() => { setShowAdd(false); setEditAlarm(null); }}
        />
      )}
    </SafeAreaView>
  );
}
