// src/components/index.tsx
import React from 'react';
import { View, Text, TouchableOpacity, ViewStyle, TextStyle, ActivityIndicator } from 'react-native';
// Direct imports from react-native-svg (NOT Svg.Polygon pattern)
import Svg, { Circle, Text as SvgText, Rect, Line, Polygon, Polyline, Path, G } from 'react-native-svg';
import { Theme } from '../types';

// ── Btn
interface BtnProps {
  children: React.ReactNode;
  onPress: () => void;
  variant?: 'primary' | 'ghost' | 'danger' | 'success' | 'muted' | 'warn';
  T: Theme;
  style?: ViewStyle;
  disabled?: boolean;
  loading?: boolean;
}
export function Btn({ children, onPress, variant = 'primary', T, style, disabled, loading }: BtnProps) {
  const v: Record<string, { bg: string; border?: string; tc: string }> = {
    primary: { bg: T.primary, tc: '#000' },
    ghost:   { bg: 'transparent', border: T.primary, tc: T.primary },
    danger:  { bg: T.danger, tc: '#fff' },
    success: { bg: T.success, tc: '#000' },
    muted:   { bg: T.lo, border: T.bord, tc: T.txt },
    warn:    { bg: T.warn, tc: '#000' },
  }[variant] || { bg: T.primary, tc: '#000' };

  return (
    <TouchableOpacity onPress={onPress} disabled={disabled || loading} activeOpacity={0.75}
      style={[{ minHeight: 44, paddingHorizontal: 18, borderRadius: 10, backgroundColor: v.bg, borderWidth: v.border ? 1.5 : 0, borderColor: v.border, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 6, opacity: disabled ? 0.5 : 1 }, style]}>
      {loading
        ? <ActivityIndicator color={v.tc} size="small" />
        : typeof children === 'string'
          ? <Text style={{ fontFamily: 'BarlowCondensed_700Bold', fontSize: 15, color: v.tc, letterSpacing: 0.5 }}>{children}</Text>
          : children}
    </TouchableOpacity>
  );
}

// ── Card
interface CardProps { children: React.ReactNode; T: Theme; style?: ViewStyle; }
export function Card({ children, T, style }: CardProps) {
  return (
    <View style={[{ backgroundColor: T.card, borderWidth: 1, borderColor: T.bord, borderRadius: 14, padding: 16 }, style]}>
      {children}
    </View>
  );
}

// ── Lbl
interface LblProps { children: React.ReactNode; T: Theme; style?: TextStyle; }
export function Lbl({ children, T, style }: LblProps) {
  return (
    <Text style={[{ fontFamily: 'BarlowCondensed_700Bold', fontSize: 11, letterSpacing: 2, color: T.muted, textTransform: 'uppercase' }, style]}>
      {children}
    </Text>
  );
}

// ── Badge
export function Badge({ children, color, T }: { children: React.ReactNode; color: string; T: Theme }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: color + '30', borderWidth: 1, borderColor: color + '66', borderRadius: 20, paddingHorizontal: 10, paddingVertical: 2 }}>
      <Text style={{ fontFamily: 'BarlowCondensed_700Bold', fontSize: 12, color, letterSpacing: 0.5 }}>{children}</Text>
    </View>
  );
}

// ── Ring (circular progress) — fixed centering
interface RingProps { pct: number; size?: number; stroke?: number; color: string; bg: string; label?: string; T: Theme; }
export function Ring({ pct, size = 64, stroke = 6, color, bg, label, T }: RingProps) {
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (circ * Math.min(pct, 100) / 100);
  const cx = size / 2;
  const cy = size / 2;

  // Adaptive font size so number fits inside ring
  const displayPct = Math.round(pct);
  const fontSize = displayPct >= 100 ? Math.round(size * 0.2) : Math.round(size * 0.23);

  return (
    <View style={{ alignItems: 'center', gap: 3 }}>
      <Svg width={size} height={size}>
        <Circle cx={cx} cy={cy} r={r} fill="none" stroke={bg} strokeWidth={stroke} />
        <Circle cx={cx} cy={cy} r={r} fill="none" stroke={color} strokeWidth={stroke}
          strokeDasharray={`${circ} ${circ}`} strokeDashoffset={offset}
          strokeLinecap="round" rotation="-90" origin={`${cx}, ${cy}`} />
        {/* Centered text using dominant-baseline and textAnchor */}
        <SvgText
          x={cx} y={cy}
          textAnchor="middle"
          dy="0.35em"
          fill={color}
          fontSize={fontSize}
          fontWeight="900"
          fontFamily="BarlowCondensed_900Black"
        >
          {displayPct}%
        </SvgText>
      </Svg>
      {label && (
        <Text style={{ fontFamily: 'BarlowCondensed_700Bold', fontSize: 10, color: T.muted, letterSpacing: 0.5, textTransform: 'uppercase', textAlign: 'center' }}>
          {label}
        </Text>
      )}
    </View>
  );
}

// ── ProgressBar
export function ProgressBar({ pct, color, T, height = 6 }: { pct: number; color: string; T: Theme; height?: number }) {
  return (
    <View style={{ height, backgroundColor: T.lo, borderRadius: height / 2, overflow: 'hidden' }}>
      <View style={{ height: '100%', width: `${Math.min(Math.max(pct, 0), 100)}%`, backgroundColor: color, borderRadius: height / 2 }} />
    </View>
  );
}

// ── BarChartSVG — direct Rect/Text imports
interface BarData { label: string; value: number; color?: string; }
export function BarChartSVG({ data, T, height = 100, color, maxVal, accentLast }: { data: BarData[]; T: Theme; height?: number; color?: string; maxVal?: number; accentLast?: boolean; }) {
  if (!data.length) return null;
  const max = maxVal || Math.max(...data.map(d => d.value), 1);
  const W = 300; const H = height - 18;
  const barW = (W / data.length) * 0.65;
  const gap = W / data.length;

  return (
    <Svg width="100%" height={height} viewBox={`0 0 ${W} ${height}`}>
      {data.map((d, i) => {
        const val = d.value || 0;
        const bH = Math.max(2, (val / max) * H);
        const x = i * gap + (gap - barW) / 2;
        const y = H - bH;
        const c = d.color || (accentLast && i === data.length - 1 ? color || T.primary : (color || T.primary) + '88');
        return (
          <G key={i}>
            <Rect x={x} y={y} width={barW} height={bH} rx={3} fill={c} />
            <SvgText x={x + barW / 2} y={H + 14} textAnchor="middle" fill={T.muted} fontSize={8}>{d.label}</SvgText>
          </G>
        );
      })}
    </Svg>
  );
}

// ── LineChartSVG — direct Line/Circle imports
export function LineChartSVG({ data, dataKey, T, height = 90, color }: { data: Record<string, any>[]; dataKey: string; T: Theme; height?: number; color?: string; }) {
  const vals = data.map(d => d[dataKey]).filter((v): v is number => v != null && !isNaN(v));
  if (vals.length < 2) return <Text style={{ fontFamily: 'Barlow_400Regular', fontSize: 12, color: T.muted, textAlign: 'center', paddingVertical: 16 }}>Нужно минимум 2 записи</Text>;

  const max = Math.max(...vals, 1);
  const min = Math.min(...vals);
  const range = Math.max(max - min, 1);
  const W = 300; const H = height - 16;
  const c = color || T.success;

  const pts = data.map((d, i) => {
    const v = d[dataKey];
    if (v == null || isNaN(v)) return null;
    return { x: (i / (data.length - 1)) * W, y: H - ((v - min) / range) * H, v };
  });

  const validPts = pts.filter((p): p is NonNullable<typeof p> => p !== null);

  return (
    <Svg width="100%" height={height} viewBox={`0 0 ${W} ${height}`}>
      {validPts.map((p, i) => {
        if (i === 0) return null;
        const prev = validPts[i - 1];
        return <Line key={i} x1={prev.x} y1={prev.y} x2={p.x} y2={p.y} stroke={c} strokeWidth={2} />;
      })}
      {validPts.map((p, i) => (
        <Circle key={`dot-${i}`} cx={p.x} cy={p.y} r={3} fill={c} />
      ))}
    </Svg>
  );
}

// ── RadarSVG — using Polygon directly
export function RadarSVG({ data, T, size = 160 }: { data: { label: string; value: number }[]; T: Theme; size?: number; }) {
  if (data.length < 3) return null;
  const cx = size / 2; const cy = size / 2; const r = size * 0.35;
  const n = data.length;
  const angle = (i: number) => (Math.PI * 2 * i) / n - Math.PI / 2;
  const pt = (i: number, scale: number) => ({
    x: cx + Math.cos(angle(i)) * r * scale,
    y: cy + Math.sin(angle(i)) * r * scale,
  });

  const gridPts = (scale: number) => data.map((_, i) => `${pt(i, scale).x},${pt(i, scale).y}`).join(' ');
  const dataPts = data.map((d, i) => `${pt(i, d.value / 100).x},${pt(i, d.value / 100).y}`).join(' ');

  return (
    <Svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      {/* Grid rings */}
      {[0.25, 0.5, 0.75, 1].map(scale => (
        <Polygon key={scale} points={gridPts(scale)} fill="none" stroke={T.bord} strokeWidth={1} />
      ))}
      {/* Axes */}
      {data.map((_, i) => {
        const p = pt(i, 1);
        return <Line key={i} x1={cx} y1={cy} x2={p.x} y2={p.y} stroke={T.bord} strokeWidth={1} />;
      })}
      {/* Data polygon */}
      <Polygon points={dataPts} fill={T.primary + '33'} stroke={T.primary} strokeWidth={2} />
      {/* Labels */}
      {data.map((d, i) => {
        const p = pt(i, 1.22);
        return (
          <SvgText key={i} x={p.x} y={p.y} textAnchor="middle" dy="0.35em" fill={T.muted} fontSize={9} fontFamily="BarlowCondensed_700Bold">
            {d.label}
          </SvgText>
        );
      })}
    </Svg>
  );
}

// ── SectionHeader
export function SectionHeader({ title, T, right }: { title: string; T: Theme; right?: React.ReactNode }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
      <Text style={{ fontFamily: 'BarlowCondensed_900Black', fontSize: 22, color: T.txt }}>{title}</Text>
      {right}
    </View>
  );
}

// ── Divider
export function Divider({ T }: { T: Theme }) {
  return <View style={{ height: 1, backgroundColor: T.bord, marginVertical: 8 }} />;
}

// ── EmptyState
export function EmptyState({ emoji, text, subtext, T }: { emoji: string; text: string; subtext?: string; T: Theme }) {
  return (
    <View style={{ alignItems: 'center', paddingVertical: 40, paddingHorizontal: 20 }}>
      <Text style={{ fontSize: 40, marginBottom: 10 }}>{emoji}</Text>
      <Text style={{ fontFamily: 'Barlow_600SemiBold', fontSize: 15, color: T.txt, textAlign: 'center' }}>{text}</Text>
      {subtext && <Text style={{ fontFamily: 'Barlow_400Regular', fontSize: 13, color: T.muted, textAlign: 'center', marginTop: 4 }}>{subtext}</Text>}
    </View>
  );
}

// ── BtnRow
export function BtnRow({ children }: { children: React.ReactNode }) {
  return <View style={{ flexDirection: 'row', gap: 8 }}>{children}</View>;
}

// Re-export SVG primitives so screens don't need separate imports
export { Svg, Circle, SvgText, Rect, Line, Polygon, Polyline, Path, G };
