// src/storage.ts — debounced save, migrations, strict types
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppState, ThemeId, UIStyleId } from './types';

const KEY = 'horizon_v4';
const NUTRITION_KEY = 'hz_nutrition';
const PHOTOS_KEY = 'hz_photos';

// Schema version for migrations
const SCHEMA_VERSION = 2;

export const DEFAULTS: AppState = {
  history: {},
  tasks: [],
  goals: [],
  journal: [],
  bodyLog: [],
  reflections: [],
  painLog: [],
  achievements: [],
  aiHistory: [],
  focus: { text: '', date: '' },
  customPlan: null,
  onboarded: false,
  user: { maxPushups: 15, note: '' },
  themeId: 'cosmos' as ThemeId,
  uiStyleId: 'default' as UIStyleId,
  aiConfig: {
    provider: 'claude',
    apiKey: '',
    model: 'claude-sonnet-4-20250514',
    endpoint: '',
    persona: '',
    systemExtra: '',
  },
  streak: 0,
  alarms: [],
  calEvents: [],
};

// Merge saved state with defaults to handle new fields
function migrate(saved: Partial<AppState>): AppState {
  const merged: AppState = { ...DEFAULTS, ...saved };
  // Ensure nested objects have all fields
  merged.user = { ...DEFAULTS.user, ...saved.user };
  merged.aiConfig = { ...DEFAULTS.aiConfig, ...saved.aiConfig };
  // Ensure Gemini model is updated to 2.5
  if (merged.aiConfig.provider === 'gemini' && merged.aiConfig.model === 'gemini-2.0-flash') {
    merged.aiConfig.model = 'gemini-2.5-flash';
  }
  // Ensure arrays
  if (!Array.isArray(merged.alarms))    merged.alarms = [];
  if (!Array.isArray(merged.calEvents)) merged.calEvents = [];
  if (!Array.isArray(merged.painLog))   merged.painLog = [];
  if (!Array.isArray(merged.bodyLog))   merged.bodyLog = [];
  if (!Array.isArray(merged.reflections)) merged.reflections = [];
  return merged;
}

export async function loadState(): Promise<AppState> {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<AppState>;
      return migrate(parsed);
    }
  } catch {
    // Return defaults on error
  }
  return { ...DEFAULTS };
}

// Debounce timer
let saveTimer: ReturnType<typeof setTimeout> | null = null;

export function saveState(state: AppState): void {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    AsyncStorage.setItem(KEY, JSON.stringify(state)).catch(() => {});
    saveTimer = null;
  }, 300);
}

export async function clearState(): Promise<void> {
  try {
    await AsyncStorage.removeItem(KEY);
  } catch {}
}

// Nutrition — separate key
export async function loadNutrition(): Promise<Record<string, { entries: unknown[] }>> {
  try {
    const raw = await AsyncStorage.getItem(NUTRITION_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch { return {}; }
}

export async function saveNutrition(data: Record<string, unknown>): Promise<void> {
  try {
    await AsyncStorage.setItem(NUTRITION_KEY, JSON.stringify(data));
  } catch {}
}

// Photos — separate key, max 20
export interface ProgressPhoto {
  id: string;
  date: string;
  uri: string;
}

export async function loadPhotos(): Promise<ProgressPhoto[]> {
  try {
    const raw = await AsyncStorage.getItem(PHOTOS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

export async function savePhotos(photos: ProgressPhoto[]): Promise<void> {
  try {
    await AsyncStorage.setItem(PHOTOS_KEY, JSON.stringify(photos.slice(0, 20)));
  } catch {}
}
