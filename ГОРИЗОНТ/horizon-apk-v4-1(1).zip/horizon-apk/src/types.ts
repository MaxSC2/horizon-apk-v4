// src/types.ts — строгая типизация, без any

export type ThemeId = 'cosmos' | 'aurora' | 'neon' | 'forest' | 'sunset' | 'steel' | 'arctic' | 'sand';
export type UIStyleId = 'default' | 'sharp' | 'soft' | 'glow' | 'rpg' | 'kawaii' | 'pixel';
export type ExerciseType = 'reps' | 'seconds';
export type PlanType = 'upper' | 'lower' | 'light' | 'rest' | 'mixed';
export type AlarmCategory = 'wake' | 'workout' | 'meal' | 'meds' | 'custom';
export type AlarmSoundId = 'default' | 'twilight' | 'chime';
export type AIProvider = 'claude' | 'openai' | 'gemini' | 'groq' | 'ollama' | 'custom';
export type CalEventCategory = 'workout' | 'goal' | 'note' | 'health' | 'study' | 'social' | 'other';
export type CalEventReminder = '' | '30m' | '1h' | '1d';

export interface Theme {
  id: ThemeId;
  name: string;
  icon: string;
  dark: boolean;
  bg: string;
  surf: string;
  card: string;
  bord: string;
  txt: string;
  muted: string;
  lo: string;
  primary: string;
  success: string;
  warn: string;
  danger: string;
}

export interface Exercise {
  id: string;
  name: string;
  type: ExerciseType;
  sets: number;
  reps: string;  // '10-15' display string
  hi: number;    // target max reps for progression
  notes?: string;
}

export interface PlanDay {
  id: number;
  name: string;
  type: PlanType;
  emoji: string;
  day: string;
  exercises: Exercise[];
  warmup: string[];
  stretch: string[];
}

export interface SetLog {
  done: boolean;
  value: string; // always string (from TextInput)
}

export interface WorkoutLog {
  dayId: number;
  completed: boolean;
  exercises: Record<string, SetLog[]>;
  difficulty: number;
  painNotes: string;
  workoutNotes?: string;
  startTime: string;
  endTime?: string;
}

export interface Task {
  id: string;
  title: string;
  category: string;
  recurring: boolean;
  completedDates: string[];
  createdAt: string;
  dueDate?: string;
}

export interface Goal {
  id: string;
  title: string;
  desc?: string;
  category: string;
  emoji: string;
  targetValue: number;
  currentValue: number;
  unit: string;
  deadline?: string;
  completed: boolean;
  createdAt: string;
  history: { date: string; value: number }[];
}

export interface JournalEntry {
  id: string;
  date: string;        // 'YYYY-MM-DD'
  text: string;
  mood: number;        // 1-5
  energy?: number;     // 1-5
  sleep?: number;      // hours as float e.g. 7.5
  waterGlasses?: number;
  waterDone?: boolean;
  createdAt: string;
}

export interface BodyMeasurement {
  id: string;
  date: string;
  weight?: string;
  height?: string;
  chest?: string;
  waist?: string;
  arms?: string;
  hips?: string;
  createdAt: string;
}

export interface WeeklyReflection {
  id: string;
  date: string;
  went: string;
  didnt: string;
  focus: string;
  createdAt: string;
}

export interface PainEntry {
  id: string;
  date: string;
  zone: string;
  intensity: 1 | 2 | 3 | 4;
  isRight: boolean;
  note: string;
  createdAt: string;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  ts: number;
  provider?: string;
}

export interface NutritionEntry {
  id: string;
  name: string;
  cal: number;
  p: number;
  c: number;
  f: number;
  time: string;
}

export interface AIConfig {
  provider: AIProvider;
  apiKey: string;
  model: string;
  endpoint: string;
  persona: string;
  systemExtra: string;
}

export interface Alarm {
  id: string;
  hour: number;
  minute: number;
  label: string;
  days: number[];  // 0=Sun..6=Sat, [] = once
  enabled: boolean;
  notifId?: string;
  vibrate: boolean;
  smartWake: boolean;
  category: AlarmCategory;
  soundId: AlarmSoundId;
}

export interface CalEvent {
  id: string;
  date: string;
  title: string;
  category: CalEventCategory;
  done: boolean;
  time?: string;
  reminder: CalEventReminder;
  notifId?: string;
}

export interface ProgressPhoto {
  id: string;
  date: string;
  uri: string;
}

export interface AppState {
  history: Record<string, WorkoutLog>;
  tasks: Task[];
  goals: Goal[];
  journal: JournalEntry[];
  bodyLog: BodyMeasurement[];
  reflections: WeeklyReflection[];
  painLog: PainEntry[];
  achievements: string[];
  aiHistory: ChatMessage[];
  focus: { text: string; date: string };
  customPlan: PlanDay[] | null;
  onboarded: boolean;
  user: {
    name?: string;
    maxPushups: number;
    note: string;
    lifeAreas?: string[];
    reminderTime?: string;
    reminderEnabled?: boolean;
  };
  themeId: ThemeId;
  uiStyleId: UIStyleId;
  aiConfig: AIConfig;
  streak?: number;
  alarms: Alarm[];
  calEvents: CalEvent[];
}

export interface WorkoutSession {
  dayIdx: number;
  phase: 'warmup' | 'exercises' | 'finish';
  warmupDone: Set<number>;
  exerciseLogs: Record<string, SetLog[]>;
  showRest: boolean;
  difficulty: number;
  painNotes: string;
  workoutNotes: string;
  startTime: string;
}
